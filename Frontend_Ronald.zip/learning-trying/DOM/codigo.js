var ruta = window.location;
        document.write("<p>Hola estudiante </p>");
        console.log("Mis datos de TDC");
        document.write("Estás en: "+ruta);