for(var i=1;i<101;i++)
{
    document.write(i%3==0? i%5==0?"fizzbuzz": "fizz": i%5==0? "fizz": i );
    document.write("<br>");
}